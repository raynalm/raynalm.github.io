#ifndef _SORTS_H
#define _SORTS_H 1

typedef const struct Prop_Node *Prop;

#ifndef _SORTS_SKIP_Nnf
// definition of an abstract datatype of pointer
typedef const struct Nnf_Node *Nnf;  
#endif

#endif
